/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Common;

import java.util.Scanner;

/**
 *
 * @author Acer Nitro5
 */
public class Validation {
    private final Scanner sc = new Scanner(System.in);

    public double getSalary(String message) {
        double salary;
        System.out.print(message);
        System.out.println();
        while (true) {
            try {
                salary = Double.parseDouble(sc.nextLine().trim());
                if (salary > 0) {
                    break;
                } else {
                    System.err.println("Salary is equal or greater than 0");
                    System.out.println("Enter agian: ");
                }
            } catch (Exception e) {
                System.err.print("You must input digit: ");
                System.out.println("Enter agian: ");
            }
        }
        return salary;
    }

   
    public String getString(String mess) {       
        while (true) {
            System.out.print(mess);
            String s = sc.nextLine().trim();
            if (s.isEmpty()) {
                System.err.println("Emtpy");
                System.out.println("Enter agian: ");
            } else {
                return s;
            }
        }
        
    }

    public String checkFormatName(String mess, String parternFomart) {
        String s;
        while (true) {
            //System.out.print(mess);
            s = getString(mess);
            if (s.matches(parternFomart)) {
                break;
            } else {
                System.err.println("Wrong format !!");

            }
        }
        return s;
    }

}
