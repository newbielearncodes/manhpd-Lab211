/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;



import common.validation;
import java.util.ArrayList;
import java.util.List;
import model.expense;


public class expenselist {
    
    List<expense> list = new ArrayList<>();
    validation check = new validation();

    
    //add new expense
    public void addExpense(expense e) {
        //add expense to list
        list.add(e);
    }
    
    //remove an expense
    public void removeExpense(int id) {
        
        //point to each expense in list
        for (int i = 0; i < sizeList(); i++) {
            expense e = list.get(i);
            //check id of expense equals input id or not
            if (e.getId() == id) {
                list.remove(i);
                resetID(i);
                return;
            }
        }
    }
    
    
    public void resetID(int n) {
        for (int i = n; i < sizeList(); i++) {
            expense e = list.get(i);
            e.setId(i+1);
        }
    }
    
    //display all expense
    public void display() {
        double total = 0;
        //point to each expense in list
        for (expense e: list) {
            System.out.println(e);
            total = total + e.getAmount();
        }
    }

    public int sizeList() {
        int size = list.size();
        return size;
    }
    
    public int checkIdExist(int id) {
        for (int i = 0; i < sizeList(); i++) {
            if (list.get(i).getId() == id) {
                return i;
            }
        }
        return -1;
    }
}
