/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import common.validation;
import controller.expenselist;
import java.util.ArrayList;
import java.util.List;
import model.expense;

/**
 *
 * @author User
 */
public class expenseView {
    expenselist exlist = new expenselist();
    validation check = new validation();
    
    public void createExpense(){
        int ID;
        //set ID auto increment
        if (exlist.sizeList()== 0) ID = 1;
        else ID = exlist.sizeList() + 1;
        String date = check.inputDate("Enter Date: ");
        double amount = check.inputDouble("Enter Amount: ", 0, Double.MAX_VALUE);
        String content = check.inputString("Enter Content: ");
        expense e = new expense(ID, date, amount, content);
        //add expense to exlist
        exlist.addExpense(e);
        System.err.println("Add new expense successfully");
    }
    
    public void removeEx(){
        int ID = check.inputInt("Enter ID: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
        if(exlist.checkIdExist(ID)==-1){
            System.err.println("ID does not exist");
        } else {
            exlist.removeExpense(ID);
            System.err.println("Remove successfully");           
        }
    }
    public void displayEx() {
        double total = 0;
        System.out.println(String.format("%-4s%-15s%-15s%-20s", "ID", "Date", "Amount", "Content"));
        //point to each expense in list
        exlist.display();
        System.out.println("Total: " + total);
    }
}
