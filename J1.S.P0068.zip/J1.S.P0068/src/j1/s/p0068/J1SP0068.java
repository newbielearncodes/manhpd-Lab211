/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0068;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Acer Nitro5
 */
public class J1SP0068 {

    /**
     * @param args the command line arguments
     */
    Validation v = new Validation();
        public void addStudent(ArrayList<Student> ar){
        System.out.println("===== Collection sort program =====");
        System.out.println("Please input student information");
        System.out.print("Name: ");
        String Name = v.InputString();
        System.out.print("Classes: ");
        String Classes = v.InputString();
        System.out.print("Mark: ");
        float Mark = v.InputFloat();
        ar.add(new Student(Name, Classes, Mark));
    }
    //ham hien thi
    private static void print(ArrayList<Student> ar){
        if(ar.isEmpty()){
            System.out.println("List Empty");
            return;
        }
        Collections.sort(ar); //sap xep danh sach
        for(int i = 0; i < ar.size(); i++){
            System.out.println("----- Student " + (i+1) + "-----");
            System.out.println("Name: " + ar.get(i).getName());
            System.out.println("Classes: " + ar.get(i).getClasses());
            System.out.println("Mark: " + ar.get(i).getMark());
        }
    }
    public static void main(String[] args) {
        J1SP0068 j = new J1SP0068();
        Validation v = new Validation();
        ArrayList<Student> ar = new ArrayList<>();
        j.addStudent(ar);
        while(true){
            System.out.print("Do you want enter more student information?(Y/N): ");
            if(v.InputYN() == 1){
                j.addStudent(ar);
            }else{
                break;
            }
        }
        print(ar);
    }
    
    
}
