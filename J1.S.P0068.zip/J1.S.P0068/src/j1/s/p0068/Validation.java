/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0068;

import java.util.Scanner;

/**
 *
 * @author Acer Nitro5
 */
public class Validation {
    private static final Scanner sc = new Scanner(System.in);
    
    //ham nhap string neu rong nhap lai
    public  String InputString(){
        String result;
        while(true){
            try{
                result = sc.nextLine().trim();
                if(result.isEmpty()){
                    throw new Exception();
                }
                return result;
            }catch (Exception e){
                System.out.print("Please enter again String: ");
            }
        }
    }
    //ham nhap va kiem tra tinh dung sai
    public  int InputYN(){
        String result;
        while(true){
            try{
                result = sc.nextLine();
                if(result.equalsIgnoreCase("Y")){
                    return 1;
                }else if(result.equalsIgnoreCase("N")){
                    return -1;
                }else{
                    throw new Exception();
                }
            }catch (Exception e){
                System.out.print("Please input Y/N: ");
            }
        }
    }
    //ham nhap va kiem tra so float
    public float InputFloat(){
        Float num;
        while(true){
            try{
                num = Float.parseFloat(sc.nextLine());
                if(num < 0 || num > 100){
                    throw new NumberFormatException();
                }
                return num;
            }catch(NumberFormatException e){
                System.out.print("Try Again: ");
            }
        }
    }
}
