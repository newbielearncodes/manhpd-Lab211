/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0050;



/**
 *
 * @author Acer Nitro5
 */
public class Menu {
    //ham hien thi menu
      public void menu(){
          
         Validate v = new Validate();
         Solving m = new Solving();
        while(true){ 
        System.out.println("====== Equation Program ======");
        System.out.println("1. Calculate Superlative Equation");
        System.out.println("2. Calculate Quadratic Equation");
        System.out.println("3. Exit The Program");
        System.out.println("Please choice one option: ");
        int choice = v.getChoice();
        
            switch(choice){
                case 1:{
                    m.InputSuperlativeEquation();
                    break;
                }
                case 2:{
                    m.InputQuadrticEquation();
                    break;
                }
                case 3:{
                    return;
                }
            }
        }
    }
}
