/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0050;

import java.util.Scanner;

/**
 *
 * @author Acer Nitro5
 */
public class Validate {
    Scanner sc = new Scanner(System.in);
    
    //ham nhap va kiem tra xem so double
    public double InputDouble(){
        double num;
        while(true){
            try{
                num = Double.parseDouble(sc.nextLine().trim());
                return num;
            }catch(NumberFormatException e){
                System.out.println("Please enter number");
                System.out.print("Enter again:");
            }
        }
    }
    
    //ham kiem tra so le
    public boolean checkOdd(double n){
        if(n % 2 != 0){
            return true;
        }else{
            return false;
        }
    }
    
    //ham kiem tra so chan
    public boolean checkEven(double n){
        if(n % 2 == 0){
            return true;
        }else{
            return false;
        }
    }
    
    //ham kiem tra so chinh phuong
    public boolean checkSquareNumber(double n){
        if((int) Math.sqrt(n) * (int) Math.sqrt(n) == n){
            return true;
        }else{
            return false;
        }
    }
    
    //ham kiem tra lua chon cua menu
    public int getChoice(){
        int choice;
        while(true){
            try{
                choice = Integer.parseInt(sc.nextLine().trim());
                if(choice < 1 || choice > 3){
                    throw new NumberFormatException();
                }
                return choice;
            }catch(NumberFormatException e){
                System.out.print("Enter again: ");
            }
        }
    }
}
