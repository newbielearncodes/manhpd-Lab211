/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0050;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Acer Nitro5
 */
public class Solving {
    
        //ham hien thi
    public void output(ArrayList<Double> d){
        //hien thi so le
         Validate v = new Validate();
        int i;
        System.out.print("Number is odd: ");
        for(i = 0; i < d.size(); i++){
            if(v.checkOdd(d.get(i))){
                System.out.print(" " + d.get(i));
            }
        }
        //hien thi so chan
        System.out.println();
        System.out.print("Number is even: ");
        for(i = 0; i < d.size(); i++){
            if(v.checkEven(d.get(i))){
                System.out.print(" " + d.get(i));
            }
        }
        //hien thi so chinh phuong
        System.out.println();
        System.out.print("Number is Perfect Square: ");
        for(i = 0; i < d.size(); i++){
            if(v.checkSquareNumber(d.get(i))){
                if (i<d.size()-1) System.out.print(d.get(i)+", ");
                else System.out.print(d.get(i));
            }
        }
        System.out.println();
    }
    
    //ham nhap phuong trinh bac nhat
   public void InputSuperlativeEquation(){
         Validate v = new Validate();
        List<Double> d = new ArrayList<>();
        double a, b;
        System.out.println("------ Calculate Superlative Equation ------");
        System.out.print("Enter A: ");
        a = v.InputDouble();
        System.out.print("Enter B: ");
        b = v.InputDouble();
        d = SuperlativeEquation(a, b);
    }
    
    //ham tinh phuong trinh bac nhat
    public List<Double> SuperlativeEquation(double a, double b){
        ArrayList<Double> d = new ArrayList<>(); 
        double x;
        d.add(a);
        d.add(b);
        if(a == 0){
            if(b == 0){
                System.out.println("Empty");//a=b=0
            }else{
                System.out.println("Null");//a!=0, b=0
            }
        }else{
            x = -b/a;
            System.out.println("Solution x = " +x);
            d.add(x);
        }
        output(d);
        return d;
    }
    
    //nhap phuong trinh bac 2
    public void InputQuadrticEquation(){
         Validate v = new Validate();
        List<Double> d = new ArrayList<>();
        double a, b, c;
        System.out.println("------ Calculate Quadrticlative Equation ------");
        System.out.print("Enter A: ");
        a = v.InputDouble();
        System.out.print("Enter B: ");
        b = v.InputDouble();
        System.out.print("Enter C: ");
        c = v.InputDouble();
        d = QuadraticEquation(a, b, c);
    }
    //ham tinh phuong trinh bac 2
    public List<Double> QuadraticEquation(double a, double b, double c){
        ArrayList<Double> d = new ArrayList<>();
        double x1, x2, x;
        d.add(a);
        d.add(b);
        d.add(c);
        double delta = b*b - 4*a*c;//tinh delta
        if(a == 0){
            if(b == 0){
                if(c == 0){
                    System.out.println("Empty");// a=b=c=0
                }else{
                    System.out.println("Null"); // a=0, b=0, c!=0
                }
            }else{
                x = -c/b; //truong hop nghiem kep de 1 ket qua
                System.out.println("Solution: x = " +x); //neu a = 0
                d.add(x);
            }
        }else{
            if(delta >= 0){
                x1 = ((-b + Math.sqrt(delta)) / (2*a));
                x2 = ((-b - Math.sqrt(delta)) / (2*a));
                System.out.println("Solution: x1 = " +x1 + ", x2 = " +x2);
                d.add(x1);
                d.add(x2);
            }else{
                System.out.println("Null");
            }
        }
        output(d);
        return d;
    }
}
