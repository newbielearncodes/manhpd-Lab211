/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0064;

import common.Validation;

/**
 *
 * @author Acer Nitro5
 */
public class J1SP0064 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Validation va = new Validation();
        String phone = va.checkInputPhone("Phone number: ","^[\\d]{10}$");//Enter the number 0 to 9 consisting of 10 digits
        String date = va.checkInputDate("Date: ");
        String email = va.checkInputEmail("Email: ","^[a-zA-Z][a-zA-Z0-9\\_]+@[a-zA-Z]+(.[a-zA-z]+){1,3}$");
    }
    
    
}
