/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bbs;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Acer Nitro5
 */
public class Main {
   private static final Scanner sc = new Scanner(System.in);
    // ham check dau vao
    private static int checkInput() {
        while (true) {
            try {
                int temp = Integer.parseInt(sc.nextLine().trim());
                if (temp < 0) {
                    throw new NumberFormatException();
                }
                return temp;
            } catch (NumberFormatException e) {
                System.out.println("Invalid Input");
                System.out.print("Please try again: ");
            }
        }
    }
    //ham nhap so luong mang
    private static int inputsizeofArray() {
        System.out.print("Enter number of array: ");
        int n = checkInput();
        return n;
    }
    //random ra gia tri mang
    private static int[] valueofArray(int n) {
        int[] a = new int[n];
        Random rd = new Random();
        for (int i = 0; i < n; i++) {
            a[i] = rd.nextInt(n);
        }
        return a;
    }
    //ham in ra mang chua sap xep
    private static void displayArrayUnsorted(int[] a) {
        
        System.out.print("Unsorted array: [");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i]);
            if (i < a.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.print("]");
    }
    // ham in ra mang da sap xep
     private static void displayArraySorted(int[] a) {
        
        System.out.print("Sorted array: [");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i]);
            if (i < a.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.print("]");
    }
     //ham sap xep

  private static void BubbleSort(int arr[]) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

    }



public static void main(String[] args) {
        int n = inputsizeofArray();
        int[] a = valueofArray(n);
        displayArrayUnsorted(a);
        System.out.println();
        BubbleSort(a);
        displayArraySorted(a);
        System.out.println();
    }
    
}